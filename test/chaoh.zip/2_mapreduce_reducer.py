# anagram Mapreduce edition

# we can use print edition
# or we can juse list edition


import sys

res = ""
for line in sys.stdin:
	res += line
print res